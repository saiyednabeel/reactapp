import React from "react";

function Single_Card(props) {
  var data = props.data;
  var image = data.links.mission_patch;
  var landing = data.rocket.first_stage.cores[0].land_success;
 
 
  const renderKeys = () => {                          // to render all the id from mission id list 
    return data.mission_id.map(val => {
      return <li>{val}</li>;
    });
  };
  return (
    <div className="card">
      <img src={image} />
      <h1>{data.mission_name}</h1>
      <h1>Mission ids:-</h1>
      <ul>{renderKeys()}</ul>
      <h1>launch year {data.launch_year}</h1>
      <h1>launch :-{data.launch_success ? "sucess" : "fail"}</h1>           
      <h1>landing :- {landing ? "sucess" : "fail"}</h1>
    </div>
  );
}

export default Single_Card;
