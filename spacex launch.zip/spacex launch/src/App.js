import React from "react";
import "./styles.css";
import Spacexlaunchprogram from "./Spacex_launch_program";
export default function App() {
  return (
    <div className="App">
      <Spacexlaunchprogram />             //Main component
    </div>
  );
}
