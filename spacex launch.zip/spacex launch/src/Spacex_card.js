import React from "react";
import Single_Card from "./single_card";
function Card(props) {
  const renderKeys = () => {
    return props.fields.map(val => {
      return <Single_Card data={val} />;                        // showing the single card 
    });
  };

  return <div className="maincard">{renderKeys()}</div>;
}

export default Card;
