import React, { useState, useEffect } from "react";
import "./styles.css";
import axios from "axios";
import Card from "./Spacex_card";

function Spacexlaunchprogram() {
  let [ResponseData, setResponseData] = React.useState("");
  let [SelectedYear, SetSelectedYear] = React.useState([]);
  let [year, setyear] = React.useState("");

  var arr1 = [];

  useEffect(() => {}, [ResponseData]);                      // to rerender every time the data change 
  
  
  
  
  
  
  const handleClick = val => {                                        // function to trigered when user select a year
    setyear(val);
    axios
      .get(`https://api.spaceXdata.com/v3/launches?limit=100`, {})          // taking the data from the api 
      .then(response => {
        setResponseData(response.data);
      })
      .catch(error => {
        console.log(error);
      });

    for (let index = 0; index < ResponseData.length; index++) {
      if (ResponseData[index].launch_year == year) {
        arr1.push(ResponseData[index]);
      }
    }
    SetSelectedYear(arr1);
  };




  const handleClick1 = val => {                                       // function to trigered when user select a year along with launchs ucess
    if (val == "true") {
      axios
        .get(
          `https://api.spaceXdata.com/v3/launches?limit=100&launch_success=true`,
          {}
        )
        .then(response => {
          setResponseData(response.data);
        })
        .catch(error => {
          console.log(error);
        });

      for (let index = 0; index < ResponseData.length; index++) {
        if (ResponseData[index].launch_year == year) {
          arr1.push(ResponseData[index]);
        }
      }
      if (val == "false") {
        handleClick3();
      }
      SetSelectedYear(arr1);
    }
  };





  const handleClick2 = val => {                     // function to trigered when user select a year and both landing and launch is successful
    if (val == "true") {
      axios
        .get(
          `https://api.spaceXdata.com/v3/launches?limit=100&launch_success=true&land_success=true`,
          {}
        )
        .then(response => {
          setResponseData(response.data);
        })
        .catch(error => {
          console.log(error);
        });

      for (let index = 0; index < ResponseData.length; index++) {
        if (ResponseData[index].launch_year == year) {
          arr1.push(ResponseData[index]);
        }
      }
      SetSelectedYear(arr1);
    }
  };

 
 
  const handleClick3 = () => {                        // to reset to first stwhen user click false 
    axios
      .get(`https://api.spaceXdata.com/v3/launches?limit=100`, {})
      .then(response => {
        setResponseData(response.data);
      })
      .catch(error => {
        console.log(error);
      });

    for (let index = 0; index < ResponseData.length; index++) {
      if (ResponseData[index].launch_year == year) {
        arr1.push(ResponseData[index]);
      }
    }
    SetSelectedYear(arr1);
  };

  const renderKeys = () => {                                    // dynamically creating button for every year
    // works fine
    var arr = [
      2006,
      2007,
      2008,
      2009,
      2010,
      2011,
      2012,
      2013,
      2014,
      2015,
      2016,
      2017,
      2018,
      2019,
      2020
    ];
    return arr.map(val => {
      return (
        <button className="button_year" onClick={value => handleClick(val)}>
          {val}
        </button>
      );
    });
  };

  return (
    <div className="main">
      <div className="homecard">
        <h1>Launch year</h1>
        {renderKeys()}
        <h1>Sucessful launch</h1>
        <button className="main-butn" onClick={value => handleClick1("true")}>
          true
        </button>
        <button className="main-butn" onClick={value => handleClick3()}>
          fasle
        </button>
        <h2>Sucessful landing</h2>
        <button className="main-butn" onClick={value => handleClick2("true")}>
          true
        </button>
        <button className="main-butn" onClick={value => handleClick3()}>
          fasle
        </button>
      </div>
      <Card fields={SelectedYear} />
    </div>
  );
}

export default Spacexlaunchprogram;
